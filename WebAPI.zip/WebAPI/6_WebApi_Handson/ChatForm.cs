// ChatForm.cs - Part of 6_WebApi_Handson
// Kafka chat application using C# and Kafka streaming
