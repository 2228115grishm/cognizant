// Contains AddCors, AddAuthentication, AddJwtBearer setup.
