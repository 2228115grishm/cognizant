// Contains AllowAnonymous controller with GenerateJSONWebToken method.
