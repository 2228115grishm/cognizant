// Kafka producer to send chat messages.
