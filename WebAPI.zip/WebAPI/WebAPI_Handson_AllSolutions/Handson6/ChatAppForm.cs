// C# WinForms chat UI that integrates with Kafka.
