// Kafka consumer to receive chat messages.
