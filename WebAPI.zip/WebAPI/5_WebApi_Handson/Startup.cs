// Startup.cs - Part of 5_WebApi_Handson
// CORS and JWT Token Authentication using Web API
